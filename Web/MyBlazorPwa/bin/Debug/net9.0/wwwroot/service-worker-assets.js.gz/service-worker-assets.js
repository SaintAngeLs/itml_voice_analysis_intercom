self.assetsManifest = {
  "version": "JQxsqyqM",
  "assets": [
    {
      "hash": "sha256-se9UhzmnZLqiCdCmE2SuoY+GoUyYI2T2MbeJq8ilNsI=",
      "url": "MyBlazorPwa.styles.css"
    },
    {
      "hash": "sha256-uu1tQSJVQHqVAoqS+gGngihEywKWCCgbGPINWXwb4so=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.64zqq5hlsa.wasm"
    },
    {
      "hash": "sha256-Xgh/NFheyQZ4/UnCvHVcggGXHW7fYKqwklQ9Emt4hv0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.axnpbm8pki.wasm"
    },
    {
      "hash": "sha256-ECdl5k6t7QHDKV9KU83xaDL8wj6Sxgi9Fl5F+e2FQvw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.kr5v22aeir.wasm"
    },
    {
      "hash": "sha256-MOdRqIQFEcBQKHVQr1+zrYj3IoOn8ku7Esvio1xCjQ0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.oyxhxg2gzi.wasm"
    },
    {
      "hash": "sha256-6uBd380zqdAh4Z2Yx7o8JGz60LpzO+Em4kBQ2lzhhIM=",
      "url": "_framework/Microsoft.AspNetCore.Components.un9omtbej9.wasm"
    },
    {
      "hash": "sha256-eZj8qw+2ce4S9FKFcoqrKqxRS2PzGe7L8JIZS+EBEX8=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.5tue1pmwje.wasm"
    },
    {
      "hash": "sha256-cLwPHA/TQSmmpbD6tgSt1Ewjm+TE7ASj7twBsfgucBk=",
      "url": "_framework/Microsoft.CSharp.040426lcby.wasm"
    },
    {
      "hash": "sha256-Buy9UH6bmPnsA0aSADu9ptAEcE0trh9fYKljeNTuWUg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.iufjlmz75m.wasm"
    },
    {
      "hash": "sha256-GkzqjZYdYEeP9uco+eTYht0/eUo//bkT0H/Eo4gLaFc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.aj30mvn6sb.wasm"
    },
    {
      "hash": "sha256-tdt5MKBvcu2iaijleS+wRlAyz4fpdXDTEBw4GsS5JR0=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.7l1djurc5w.wasm"
    },
    {
      "hash": "sha256-P9KCq9kT5MdGgy6waDSEFkUR2X2MAoB9w8Hy2MRe8nw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.z37pqux57u.wasm"
    },
    {
      "hash": "sha256-7wHCCQMfvJf+UWjdZsUmvQXiRfk/yXMZS+u2xawiW+o=",
      "url": "_framework/Microsoft.Extensions.Configuration.tdy0oi3aza.wasm"
    },
    {
      "hash": "sha256-JfgUGo+JNJXE/5p0vTuyYh4MYcBkKZqQCYs/CMzvFoE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7d8itcedfr.wasm"
    },
    {
      "hash": "sha256-fkOF87utniM0/BFM4ZhLHIr956OyT4VTQMKJoJWujOk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.mure7uul1a.wasm"
    },
    {
      "hash": "sha256-5mX31KvO4ekHdg6yVj2OyIIVm1DkMKlQmTVaGM1l9rg=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.uayxiqwhd7.wasm"
    },
    {
      "hash": "sha256-/W0lIpDLKHfMM9nICto0cMzjV3dtYxAbHlXS5SuKzPs=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.jc8jpyi9zs.wasm"
    },
    {
      "hash": "sha256-Ig9sZDk9olvkHgbudvy6TAZtHpzJCW4SnCfP2HdhbHU=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.izqdrfxixx.wasm"
    },
    {
      "hash": "sha256-8oP4lvGwNRTr6Xq5WcP7GnHY0VEIqiGmCk3D+5cBAiI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qtekk4dwmv.wasm"
    },
    {
      "hash": "sha256-9BXix4Pfm6WwkCUs1NaztKaGz3erN4a4OmhyN+IDFeQ=",
      "url": "_framework/Microsoft.Extensions.Logging.oprjrz74h9.wasm"
    },
    {
      "hash": "sha256-CJv6tJUcivfHr40JvSFffN4gwMvGYDD3Gyc3xkTJJhY=",
      "url": "_framework/Microsoft.Extensions.Options.02zqxgr6ek.wasm"
    },
    {
      "hash": "sha256-gsj62A3q2fYmGSQT3NfJh/25OmmTkV9GiFMLXaw41PM=",
      "url": "_framework/Microsoft.Extensions.Primitives.elsvi1flzv.wasm"
    },
    {
      "hash": "sha256-YVUTXFxgrTmEdIR8uwNEPQqxEhKTFcaTCio0hJYJnQo=",
      "url": "_framework/Microsoft.JSInterop.76o9g66u2l.wasm"
    },
    {
      "hash": "sha256-8icQOPgl2Gp7J7mFGDwRCzeYWBgcy9z65/B3Sm07byA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.63svs3oyeo.wasm"
    },
    {
      "hash": "sha256-2YbZ3YgRG4ylrWoGgvFqNbDgLRJR3O+ObuFCFRQeaEw=",
      "url": "_framework/Microsoft.VisualBasic.Core.zh694vtzg6.wasm"
    },
    {
      "hash": "sha256-8obBVpUoCG803As8erMLxURfsTPD+4mWq7Ey7uNeJ+A=",
      "url": "_framework/Microsoft.VisualBasic.aymjkek7hj.wasm"
    },
    {
      "hash": "sha256-KNd7SubyFO/NQuU1Vd181rL4O2Vr7wDsvaD9iyEYDDc=",
      "url": "_framework/Microsoft.Win32.Primitives.8g1euju50x.wasm"
    },
    {
      "hash": "sha256-u6Y6wt7YxLnwRO3glLWlPNp8meO0XEVzxmVh08ja1e0=",
      "url": "_framework/Microsoft.Win32.Registry.5wwzwiycxz.wasm"
    },
    {
      "hash": "sha256-uv77N7OqLCg3VchSECo+jGXXcT6Y4BZXc02fE5lC1YI=",
      "url": "_framework/MyBlazorPwa.awbiqy1no7.pdb"
    },
    {
      "hash": "sha256-eYgRCI/wZWy78l5s1K6gYwotxwltiRyvs1UAQxC2fh8=",
      "url": "_framework/MyBlazorPwa.bjlqcvi8li.wasm"
    },
    {
      "hash": "sha256-6KkuEPevfr3sugd6X84AJtMkVL+5wj7dG8ptfZGlKUI=",
      "url": "_framework/System.AppContext.kpgmc7xhg4.wasm"
    },
    {
      "hash": "sha256-bjdn+NdKe9xmfI84hsHxGI41JpdH+8hy9gR1S76gJgg=",
      "url": "_framework/System.Buffers.2bewvub7d4.wasm"
    },
    {
      "hash": "sha256-DJdXU3qqG76/3gK9/rWCqcj7i3fGN1Ve0kk8PUyadCE=",
      "url": "_framework/System.Collections.Concurrent.ciq73xucok.wasm"
    },
    {
      "hash": "sha256-D2DgY2mM7R5ZEluhSgIIT7/BRNHTnL3WdPp7b7+5vKE=",
      "url": "_framework/System.Collections.Immutable.rhxebt0h58.wasm"
    },
    {
      "hash": "sha256-qLkWT6HFxrfZCGRDmQjKbRf0sV9d1En77n4/3kBbQzo=",
      "url": "_framework/System.Collections.NonGeneric.41v5ej2k98.wasm"
    },
    {
      "hash": "sha256-zD34BCEn/RL002f9ixrqbtmIYK7z03wLlx3Ff59MysI=",
      "url": "_framework/System.Collections.Specialized.sea2dl80lf.wasm"
    },
    {
      "hash": "sha256-PBxktIexXNsfolF4Ks8ZzWI59duZrIz6sbeO/h5otzY=",
      "url": "_framework/System.Collections.km9i7h5u0e.wasm"
    },
    {
      "hash": "sha256-XfPobEKhO9CQFe26Ug96Wt+wHaH5iUXsj02HdyifkAU=",
      "url": "_framework/System.ComponentModel.Annotations.7769d6weao.wasm"
    },
    {
      "hash": "sha256-emkcV8hQ5D7GGPDpkxtvF6I+S76zeFHKfvcW3VujHsc=",
      "url": "_framework/System.ComponentModel.DataAnnotations.m4i380txd3.wasm"
    },
    {
      "hash": "sha256-zK7LZ9fEUTMr52/VAWHdjeYcId9MRW6YL62/UkZLO/I=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.4edk6as9r6.wasm"
    },
    {
      "hash": "sha256-b0M0xtwQzsO+30AYsoo1gP9vTs6mnbgB50O5UaLEVoc=",
      "url": "_framework/System.ComponentModel.Primitives.9udyudp6qo.wasm"
    },
    {
      "hash": "sha256-wZL47bAa//CzEnmUHtO/Hd3e6cGZHp5fq7daDofLNYw=",
      "url": "_framework/System.ComponentModel.TypeConverter.zbtroi0w9b.wasm"
    },
    {
      "hash": "sha256-+hfnKSeSJgrg7WLdxUuCZFHjoUyrgh6voyQ4LJAIEwU=",
      "url": "_framework/System.ComponentModel.ajtuf20pxe.wasm"
    },
    {
      "hash": "sha256-fhhAtLY9Tln0JjMATLGauVdzF2BHSzu/9yZrHGKs6PY=",
      "url": "_framework/System.Configuration.uxol2pvhal.wasm"
    },
    {
      "hash": "sha256-tlYteSs5AG/1OvVjZKytfJTawvEuGncsE0flTl5InAw=",
      "url": "_framework/System.Console.qgniywkdbm.wasm"
    },
    {
      "hash": "sha256-gyxw/lexM5Ow+0J53LkMHi5JCntAUQaAcCbirzfcBw0=",
      "url": "_framework/System.Core.do9e3etsc1.wasm"
    },
    {
      "hash": "sha256-BBVMgbSRIvzLEPSdNGgEUZ6sE4uT/vpaJt6PdsEvhTM=",
      "url": "_framework/System.Data.Common.4adn0ysjpf.wasm"
    },
    {
      "hash": "sha256-kyiNqh8PhJ/qE7Ugy75g3mruQUkH+/rhLqtZrfjdwRI=",
      "url": "_framework/System.Data.DataSetExtensions.xvb9zck5vq.wasm"
    },
    {
      "hash": "sha256-Sfy1t3TNOedY6KPzEDMj/aumkqqdp0ey6AKfn865oko=",
      "url": "_framework/System.Data.xmljwmpp1f.wasm"
    },
    {
      "hash": "sha256-E+Wdup5r1wWLvn8CgJ3C52V7vmo6g41QZD0vWz/BP3w=",
      "url": "_framework/System.Diagnostics.Contracts.phv6qfojrg.wasm"
    },
    {
      "hash": "sha256-DkwAzAHKMei8fIO85nTyUKEBbAOWVPCgToZv4vzMjRQ=",
      "url": "_framework/System.Diagnostics.Debug.y8botuv44a.wasm"
    },
    {
      "hash": "sha256-IBVsNHtVCZIErr26cyP1pKeb58UmpoYJseRI+FBpI14=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.4nu80ay15q.wasm"
    },
    {
      "hash": "sha256-MBOE5ICOqYyFkdIud9mcaA0P7/V7TBK9fO/OpupbOs8=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.wo5435u8ho.wasm"
    },
    {
      "hash": "sha256-D/W31DzhxeBmIM7gZz1qyRoCtj/ZUhFej4rYUoY7Gns=",
      "url": "_framework/System.Diagnostics.Process.zzo6pmy94p.wasm"
    },
    {
      "hash": "sha256-11oMDMri97eOX8H4a4SYMAGOe00c0NYv5e+o6+xWsBM=",
      "url": "_framework/System.Diagnostics.StackTrace.p4kp7n5gao.wasm"
    },
    {
      "hash": "sha256-zKfqPOP3Ochmv5KngBAwHhprxx/EJxsTIdFDUtz3NPA=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.sg39aljt5x.wasm"
    },
    {
      "hash": "sha256-rRAyRf9baXpzC3tWGXXKJwfQT9e9IhggqXAN4ugCBLU=",
      "url": "_framework/System.Diagnostics.Tools.l6sk9zfd9d.wasm"
    },
    {
      "hash": "sha256-5wcE6bEMYVUBJmcnMB2JiLoLHsPMaC5WIhstZioTyvA=",
      "url": "_framework/System.Diagnostics.TraceSource.jtkyaguc63.wasm"
    },
    {
      "hash": "sha256-2Bi6bl3EWnqxkrP+RNrqzkb+IR3++rg11y2GQg5Ia0s=",
      "url": "_framework/System.Diagnostics.Tracing.8ockm95aqc.wasm"
    },
    {
      "hash": "sha256-34IdlCYVSOV8W1OqMiw/c4xFOAcxiePUxFOD1PPHalg=",
      "url": "_framework/System.Drawing.Primitives.r9klpgnzm4.wasm"
    },
    {
      "hash": "sha256-QRwpzu8YIeDm7HfFrx2bUipUkNJ4K1NsRAiJtD7YPZA=",
      "url": "_framework/System.Drawing.fgv6f83l8v.wasm"
    },
    {
      "hash": "sha256-Q7ByvJes4vzh++Jp+Dn5UsZeNIyxVJPuMa0dxLC6BLw=",
      "url": "_framework/System.Dynamic.Runtime.h7rgqqipn2.wasm"
    },
    {
      "hash": "sha256-q8zHh1CNWAOW9riqIiHfRjxjk4eqG3P67lDa0NisYRw=",
      "url": "_framework/System.Formats.Asn1.xtambm113d.wasm"
    },
    {
      "hash": "sha256-bgNa4vQqYS3q6fn4NYlZjm75bdXm1N8Yq7A48vO9cmk=",
      "url": "_framework/System.Formats.Tar.ehepviqxg7.wasm"
    },
    {
      "hash": "sha256-yAzB+n2BD7UH3x+3e1JyfIWKD06sC8hwhDIO2Bn+J7s=",
      "url": "_framework/System.Globalization.Calendars.8k7y6vdx36.wasm"
    },
    {
      "hash": "sha256-4CHiIVDxhrhu7O9wE1wKR52O8hAUjIYXaPtPVeMYZII=",
      "url": "_framework/System.Globalization.Extensions.kn1eqqiklm.wasm"
    },
    {
      "hash": "sha256-Tl209FAJOswCq3pK/z+XK5gZnKls4RmdP5vdoeAzjaA=",
      "url": "_framework/System.Globalization.ucgebq4tis.wasm"
    },
    {
      "hash": "sha256-1EBVJ1z6K5ufkkFrDxjy8bjtKFA1fS3Vse8VOfZeaB4=",
      "url": "_framework/System.IO.0v5ea0ar5l.wasm"
    },
    {
      "hash": "sha256-+qrIeJzFprOFCLLYr5VtkY2s8LLZBN9xHwyj6CLEjoY=",
      "url": "_framework/System.IO.Compression.Brotli.qv9wbgryd9.wasm"
    },
    {
      "hash": "sha256-66S/iPcig2WDsP7cY/YH1vLD2sxNRD/x+iU8Wrr0NFk=",
      "url": "_framework/System.IO.Compression.FileSystem.h9old0wrt1.wasm"
    },
    {
      "hash": "sha256-srAQGMDJx+LdbB1Hvh7jtHEhn+RNpAcA1jTRquQmWJA=",
      "url": "_framework/System.IO.Compression.ZipFile.qxpwg9jsh4.wasm"
    },
    {
      "hash": "sha256-Rgm9ptsEhK+y1A3MoGwDW2V/uQtV5gU/ptaQ0wINNVg=",
      "url": "_framework/System.IO.Compression.enzttsn8g8.wasm"
    },
    {
      "hash": "sha256-QxG3WMXZHZ2o/OmBxYvGLuJq77hgo2GrHmECqGYw4/Q=",
      "url": "_framework/System.IO.FileSystem.9takvjtg1r.wasm"
    },
    {
      "hash": "sha256-G8JtYE6ooXkiud0W1+XOw7ClgNgJLKRIn0jqcdCTnGI=",
      "url": "_framework/System.IO.FileSystem.AccessControl.jauvnogtgf.wasm"
    },
    {
      "hash": "sha256-JNsyHG94mRPb//RS61kVYOuW5HN8oHPcz4Ty5oANWfg=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.c8boe63825.wasm"
    },
    {
      "hash": "sha256-O24plupRpFuYrrgihBDM70JIbQe2+ovADhPyrxwTR08=",
      "url": "_framework/System.IO.FileSystem.Primitives.takodye5ce.wasm"
    },
    {
      "hash": "sha256-uJ5HuKwjmUPfRjBJV7bKLqk7vKzcK4DL3VaObVh5XRA=",
      "url": "_framework/System.IO.FileSystem.Watcher.8gw4k05ghl.wasm"
    },
    {
      "hash": "sha256-uiTJp0jw5XyBlxAdZjzu8o65tON2t3D4ET/o9wLzBsg=",
      "url": "_framework/System.IO.IsolatedStorage.i15b9dfcdx.wasm"
    },
    {
      "hash": "sha256-aGo4HtXX3eAkecazsiLNTG0XJ3GgQE2li0nweIioin8=",
      "url": "_framework/System.IO.MemoryMappedFiles.wy4xnf89nt.wasm"
    },
    {
      "hash": "sha256-bw4xlcDNQ4s80sJ2HaAoN54BSmNGKgH5+6222EdA/SI=",
      "url": "_framework/System.IO.Pipelines.znpy0a7i83.wasm"
    },
    {
      "hash": "sha256-FH3pWMZrjke0av/zZz02qa29y9SYe9TqNXxrwGFjQvE=",
      "url": "_framework/System.IO.Pipes.AccessControl.gny274rzdc.wasm"
    },
    {
      "hash": "sha256-x550HMQk64a+0GR5x1gPNAym5GY5TIhTB0T5Bk0H4Ms=",
      "url": "_framework/System.IO.Pipes.hakqwi9d4o.wasm"
    },
    {
      "hash": "sha256-7A2L576uNFiSk+mBuwbwjFlnu5bCaoCq3VHxjosf1rs=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.s232yx3rfg.wasm"
    },
    {
      "hash": "sha256-Js09ZBinitYkrXkRtqIV6/H80CzObUYPxXCdAPOoJG8=",
      "url": "_framework/System.Linq.Expressions.qz6fkqc40c.wasm"
    },
    {
      "hash": "sha256-7UqyTuNSze+sAiu3EyemYmWdcaEtm5HkK39RHjuWsWA=",
      "url": "_framework/System.Linq.Parallel.30d9bwe7yk.wasm"
    },
    {
      "hash": "sha256-ByPl8pDUfzIktBqgSe/Rv/vJfJlNj7f49uj74i1MtTg=",
      "url": "_framework/System.Linq.Queryable.n4y57sdjpa.wasm"
    },
    {
      "hash": "sha256-4MYCkomSKG21MZn0Mrqq9T2oDQhECU5Nn7qe9TZkJ+o=",
      "url": "_framework/System.Linq.c1n245q0cv.wasm"
    },
    {
      "hash": "sha256-87rUij4LMnMsWHCCMepr5nl25T56rBLa0av20LTgP+o=",
      "url": "_framework/System.Memory.zsa9wvm7dh.wasm"
    },
    {
      "hash": "sha256-OQ0TqqxiT4Z/Rgpemx0DR8CHWWEuaVc27w4fOrRNJcI=",
      "url": "_framework/System.Net.Http.5dqrb14mpj.wasm"
    },
    {
      "hash": "sha256-U/+YLcgaLQ6YVuK7Y+alVg4TThos4wEOlFAsJU1ATco=",
      "url": "_framework/System.Net.Http.Json.pppak3yru4.wasm"
    },
    {
      "hash": "sha256-pp7sH6tV4BYzyFT6u+qZ5/Piw8D1lnAsQP2RHQPhmmI=",
      "url": "_framework/System.Net.HttpListener.avglypzndq.wasm"
    },
    {
      "hash": "sha256-ncGwTMgxY/vk6KPsIxboprKIn8jWKThK706TbKG3q+I=",
      "url": "_framework/System.Net.Mail.flm8yiz4ef.wasm"
    },
    {
      "hash": "sha256-xkCstYMfiBpMutzBYpslklYJ2xlFUBUeKQPJV7r3pg0=",
      "url": "_framework/System.Net.NameResolution.mol0n3z9ni.wasm"
    },
    {
      "hash": "sha256-BO/4utpXRvOLpu9bTzQtiFMrc4PdQ3QimqYJitF8pI4=",
      "url": "_framework/System.Net.NetworkInformation.4mah5nynyz.wasm"
    },
    {
      "hash": "sha256-xhwZ0co8/tae4NX9gD/60g3sh5PPlCwzyng9ClVOGd8=",
      "url": "_framework/System.Net.Ping.ujbb8npehz.wasm"
    },
    {
      "hash": "sha256-CV9bl47CFEMuF2rkdZ25TNZ3mv6x0MzLHlhPs0XrsSI=",
      "url": "_framework/System.Net.Primitives.5tvcnbbsvz.wasm"
    },
    {
      "hash": "sha256-n48rh2e2ZNPObmDmeMgBX/QiDUwD1s8xnXzEi0XtZXQ=",
      "url": "_framework/System.Net.Quic.9e29kefq48.wasm"
    },
    {
      "hash": "sha256-BjgaSD9NBeizX6wPKIuJ88bs4VPFQzb0Y0dK3+B6+Bw=",
      "url": "_framework/System.Net.Requests.ev9waps3o7.wasm"
    },
    {
      "hash": "sha256-V5s0LST8EAXchaN998+6eTfngJ4O3mkaWVKBmaZHvJE=",
      "url": "_framework/System.Net.Security.9snpcpxye6.wasm"
    },
    {
      "hash": "sha256-iDTdP/cD0tEE//A5/pAmCRwV8vmT8Sogt5caiXO6tq4=",
      "url": "_framework/System.Net.ServicePoint.w6porlvxbt.wasm"
    },
    {
      "hash": "sha256-Ifn2pTo35q6N90CC+/JfvnM2ozS6XH13e/aGxS0mMiA=",
      "url": "_framework/System.Net.Sockets.rldgyns2vs.wasm"
    },
    {
      "hash": "sha256-ZZYieRvx/foj9N7AWjQ1tzhvwE2P8xGATNrJii3m4kk=",
      "url": "_framework/System.Net.WebClient.xheghi3asb.wasm"
    },
    {
      "hash": "sha256-YGrV3ccSzgcinSkMVsROwEor++mwZoMEfwF961HRXM4=",
      "url": "_framework/System.Net.WebHeaderCollection.8e2t1uivn2.wasm"
    },
    {
      "hash": "sha256-gnTA1WSi0EHO3Wc4eqXKbM7B90vIbwFpQyYPQVFADcA=",
      "url": "_framework/System.Net.WebProxy.meb7ab4j6d.wasm"
    },
    {
      "hash": "sha256-2cqFWYvz8TKUn1cttG7YQbXMpzMyGOexudd7KMHwl0I=",
      "url": "_framework/System.Net.WebSockets.Client.r3qkg1wb41.wasm"
    },
    {
      "hash": "sha256-7BqOaLQyG+/69VR8rFxlvz4c8Ba5WVIDQan/4QhCMvE=",
      "url": "_framework/System.Net.WebSockets.g5pnqflbew.wasm"
    },
    {
      "hash": "sha256-hHoRLxcaCbAL0dsgcwH2jpT+me3r+3HouoPYg3ul1WU=",
      "url": "_framework/System.Net.wl3x226oxo.wasm"
    },
    {
      "hash": "sha256-5acBmlvug285rEI8G5JX8jZXjrlh0Mmr5H+LiUh7rYQ=",
      "url": "_framework/System.Numerics.Vectors.l0hr1mipn0.wasm"
    },
    {
      "hash": "sha256-kDEkLJqIZ22xMx9oA2f5wmxFJ/BJHfMrfJGR5TulqQo=",
      "url": "_framework/System.Numerics.oihbljo7yk.wasm"
    },
    {
      "hash": "sha256-VJ1ICp8h2lyuJOfiRxSSknvaHfmMY4FAPJ4tQxJ6AQw=",
      "url": "_framework/System.ObjectModel.swpu8jp72z.wasm"
    },
    {
      "hash": "sha256-oJ0gf2QSLKDnY4kTmWUGx56KHB77Dzt74S3KirGcxSk=",
      "url": "_framework/System.Private.CoreLib.47yd44euaz.wasm"
    },
    {
      "hash": "sha256-Tr0vro5Mw06vzqlmaqb4322yfJI6PjOwYkQZGoZC8Fo=",
      "url": "_framework/System.Private.DataContractSerialization.q60jvrb9f9.wasm"
    },
    {
      "hash": "sha256-luuZld/d6y5QoAlW9pyeJqNShTB4/JRHx+BT43Oq7QY=",
      "url": "_framework/System.Private.Uri.m8mcc10zcx.wasm"
    },
    {
      "hash": "sha256-EkT0IpMdtdHdDzYO+GCmjWvcye8EKG/ub45FvcYiRLQ=",
      "url": "_framework/System.Private.Xml.Linq.egur1isovl.wasm"
    },
    {
      "hash": "sha256-1wQoG7tKpfljxvHCMrHAxVuZblMuegj77nRkZQr7X2c=",
      "url": "_framework/System.Private.Xml.vus7rfiveq.wasm"
    },
    {
      "hash": "sha256-JvaJIpKe29neN/R8lEb0sB71XTC8wD0ZJvmNW2UKrxo=",
      "url": "_framework/System.Reflection.DispatchProxy.i6netg2o2l.wasm"
    },
    {
      "hash": "sha256-KiJ79/G+iagL1+DKIBpTQgDq4nELSgrdJ0TAoF4pUfk=",
      "url": "_framework/System.Reflection.Emit.2qsfvp6sex.wasm"
    },
    {
      "hash": "sha256-sfq9Zo93I1DK45olC7qVnxBhi3YtBtOheturTfdJ1K0=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.3bkq4q72mm.wasm"
    },
    {
      "hash": "sha256-nN6Ii6kKSLS7K0amZLj4qYsXRmt7zmdMLNhvuWLk2Tk=",
      "url": "_framework/System.Reflection.Emit.Lightweight.wd7sl2drvs.wasm"
    },
    {
      "hash": "sha256-Boa3pj5+DfkCWN4tiLSKIKFUdaxrOpRcR0OFNzzUf6U=",
      "url": "_framework/System.Reflection.Extensions.2tfsjh3dx8.wasm"
    },
    {
      "hash": "sha256-FKg6SrhhoUWhb+49Afjv8wK1NDsnHgc5KCKibC9mWPs=",
      "url": "_framework/System.Reflection.Metadata.857j91qbep.wasm"
    },
    {
      "hash": "sha256-JJ0D1+578yG4cops+mAhDDm99IBmTLNbFZFg1vWTzpA=",
      "url": "_framework/System.Reflection.Primitives.8dkbr3s6hx.wasm"
    },
    {
      "hash": "sha256-iPtldgyKhMZ1S3IJZ5y5nGlF2KwL54oPbKwIpv1aOAQ=",
      "url": "_framework/System.Reflection.TypeExtensions.ocohqj2z83.wasm"
    },
    {
      "hash": "sha256-wrPvX20vJzZ7qsEupFYS9MdAGM/XH98Z78L1Ze987/g=",
      "url": "_framework/System.Reflection.exxsp8wpj7.wasm"
    },
    {
      "hash": "sha256-eLN3unKj0OqBchjeHJdYuRq951Uix/XYYFPvBBdaNAU=",
      "url": "_framework/System.Resources.Reader.szw2dnd6jm.wasm"
    },
    {
      "hash": "sha256-Z8O0Gabhbpzna0SlBYPMnUNP99fBUHOCgwKzkdwdAmM=",
      "url": "_framework/System.Resources.ResourceManager.t7cbiy536o.wasm"
    },
    {
      "hash": "sha256-luuUuRDotoidRuwsz9Kpv+vvZebdICfex2EPUsjfQmo=",
      "url": "_framework/System.Resources.Writer.iqrs9scpt4.wasm"
    },
    {
      "hash": "sha256-Pixwkk+6g4LWXtriNuBGztV4NpNW1b/w7L+HptwTfdA=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.ycvca4l234.wasm"
    },
    {
      "hash": "sha256-J9/EJLjToo8uliF/r0vOyK7ofW6fB/kmNXe/3w9rR88=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.jxz5ak458s.wasm"
    },
    {
      "hash": "sha256-t3uVctEea0uUHxAKVPIfh7Baw49BdUAbIbZ5DiEhfkE=",
      "url": "_framework/System.Runtime.Extensions.9g4bxuaw3p.wasm"
    },
    {
      "hash": "sha256-TYcztXwty2KDB1lko+nJ+1BAsaAbKZdA/iCGCa9POuk=",
      "url": "_framework/System.Runtime.Handles.flz2cbgrom.wasm"
    },
    {
      "hash": "sha256-Lt3trJONsIwW9QtLzsUXadRR+M6tfWbN4qjqwQ2++Ms=",
      "url": "_framework/System.Runtime.InteropServices.6md9w8332d.wasm"
    },
    {
      "hash": "sha256-qaXT/A3M4sjvg8bZNW1wstIDoi5m6pFGDKTOfE6uyNc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.nomi7o9vbg.wasm"
    },
    {
      "hash": "sha256-8sSTrAj7M47eMnWlK7JT5JTEzm/CpERidSKtPH5Ygbo=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.ma51qkg5sm.wasm"
    },
    {
      "hash": "sha256-nVXXi6kM+NnmIv4cZM7q8b6VDCJsdbc79Fa6oUUAGZA=",
      "url": "_framework/System.Runtime.Intrinsics.zs58r06u1a.wasm"
    },
    {
      "hash": "sha256-drYucX0u+SecSq00yu/jKUZzov7+5/XFTnkZP8qQzc0=",
      "url": "_framework/System.Runtime.Loader.a4j7ts4uf5.wasm"
    },
    {
      "hash": "sha256-YJtZczA8MImp9aCVmNxaGwl72H2sE4+Vsr5D6zgPOzU=",
      "url": "_framework/System.Runtime.Numerics.82pn6wcu74.wasm"
    },
    {
      "hash": "sha256-bUskwLTaCBy6IKiUez1As9iGdetWM7A6OxtS9XUsKSk=",
      "url": "_framework/System.Runtime.Serialization.77pwd4zm8r.wasm"
    },
    {
      "hash": "sha256-0bvoiDJMLyHK3n69MPFXEfkih1v/RAffxM1dAyX2q7A=",
      "url": "_framework/System.Runtime.Serialization.Formatters.znxzv8p2p0.wasm"
    },
    {
      "hash": "sha256-xMRlw+cGopTih1Klc2BUTkoBNpMyEvkM2N7Ap5e4Xng=",
      "url": "_framework/System.Runtime.Serialization.Json.s0u195thmc.wasm"
    },
    {
      "hash": "sha256-VNOqFzQFh0tEHdyTWKOYvL/Ch9XTFy16B/Loik8/nCo=",
      "url": "_framework/System.Runtime.Serialization.Primitives.s2fscvnz81.wasm"
    },
    {
      "hash": "sha256-/fi6jCG3BMuWaUp8vMUdX+da5u2ZvRbjQcFEBb24lgA=",
      "url": "_framework/System.Runtime.Serialization.Xml.bq5sr8mqu3.wasm"
    },
    {
      "hash": "sha256-jJCB8iecBC56gj24KePLo6p4Y391UIYzGqjzCQ4gfQ8=",
      "url": "_framework/System.Runtime.kq1zdkaomh.wasm"
    },
    {
      "hash": "sha256-0pUcRkjYrZzrevDt89Hzjw/P3ykiYjkgA4eqp+uGr7A=",
      "url": "_framework/System.Security.6uvsurntj9.wasm"
    },
    {
      "hash": "sha256-yxXjNZTj/5/U0clUzAuUkY7uRgzpRpi8yUVKztlSWGc=",
      "url": "_framework/System.Security.AccessControl.54i2yc9qas.wasm"
    },
    {
      "hash": "sha256-VOWoxm/syBKVjl95eF46UgWh/4W25IE7DSWATAqtQ9s=",
      "url": "_framework/System.Security.Claims.ck5i6efy1h.wasm"
    },
    {
      "hash": "sha256-qNvnLqjE5cwq0m96h4J/CtwYeGSx/bWE7MyZlmN2/Lg=",
      "url": "_framework/System.Security.Cryptography.Algorithms.oc2zx18gml.wasm"
    },
    {
      "hash": "sha256-NJqB6Nk/1RJPU0W47IZY9pETEW7nz7YnGvoKnSzxwo8=",
      "url": "_framework/System.Security.Cryptography.Cng.83kutjrbfy.wasm"
    },
    {
      "hash": "sha256-8YryLRUoURF72yAmGpazYrTBmL2NT/4wmbbszlCNNP4=",
      "url": "_framework/System.Security.Cryptography.Csp.9q8vhjzt28.wasm"
    },
    {
      "hash": "sha256-FHO1WAcznpNhr+IGMBgruQnVqxrYnFfB1uLkv5bGHQM=",
      "url": "_framework/System.Security.Cryptography.Encoding.0p94ll42w4.wasm"
    },
    {
      "hash": "sha256-M9wmDzNV95QD8dM4/c0LZIvpSdwUy9GCJmqWhhRBY9U=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.reysb5utq2.wasm"
    },
    {
      "hash": "sha256-timqr16ETpVncxkXiH2E1VsGMbMjiiMqgJ3LEsZE9PQ=",
      "url": "_framework/System.Security.Cryptography.Primitives.e6d42nlj8r.wasm"
    },
    {
      "hash": "sha256-+OhA25UBGwKt4nxDBw9xpGiS84i3NzQOfBwEbo3unbE=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.8kri7tcciu.wasm"
    },
    {
      "hash": "sha256-edIdh+bRACMGYN84XZjHC4n44O0cmyRdfdTrfeAsVLs=",
      "url": "_framework/System.Security.Cryptography.l1g1nhvy77.wasm"
    },
    {
      "hash": "sha256-eS+tv2CNmj8JCDwRNwoXNtY7NKwzZ+oovd5rppZvp2U=",
      "url": "_framework/System.Security.Principal.Windows.511lfqaml1.wasm"
    },
    {
      "hash": "sha256-Ayb5WLAwEXaGlbHVYs/qDtT+o4n9OlzJVR+wDawgCLs=",
      "url": "_framework/System.Security.Principal.lm1j3qcswl.wasm"
    },
    {
      "hash": "sha256-tDoe8A9Nyddchs/vKIY2UfRiL4oJFnnd8pL3jjAJSDQ=",
      "url": "_framework/System.Security.SecureString.g96wz4grqo.wasm"
    },
    {
      "hash": "sha256-Zjc3P17dg1187sGYIlQrQdzlgUOPRpANh6sMUEu5XTw=",
      "url": "_framework/System.ServiceModel.Web.eeeq8lbx8d.wasm"
    },
    {
      "hash": "sha256-xoLEcciTDgqzJ4yxU3pjmtlTyY/tL3MFA1SN1VMWhPg=",
      "url": "_framework/System.ServiceProcess.qgald22zps.wasm"
    },
    {
      "hash": "sha256-K4HZkFQtPkIdMTkpY1qKBtAUpelWVJZbVla3a9RCtBk=",
      "url": "_framework/System.Text.Encoding.CodePages.r8rpvfddou.wasm"
    },
    {
      "hash": "sha256-5pHVG6PvYjsFSMKzXuj+WZryXCwD5In0CWVWEiCQi+Q=",
      "url": "_framework/System.Text.Encoding.Extensions.itwzxw4abd.wasm"
    },
    {
      "hash": "sha256-FPx7156/njLydyg91ZPPTE/h9gsjpxFEZOK2p2vtcgA=",
      "url": "_framework/System.Text.Encoding.wz6ik7431t.wasm"
    },
    {
      "hash": "sha256-m1q6KFlRebRFtbrPicNKnP5K5DBdS/EL4TUwOJrstps=",
      "url": "_framework/System.Text.Encodings.Web.rst7oo1tmr.wasm"
    },
    {
      "hash": "sha256-kzVgXBtY/d66mKcA77qoN6RBP06XlWI3P+wFkYSxW2Y=",
      "url": "_framework/System.Text.Json.dgq6b5if3h.wasm"
    },
    {
      "hash": "sha256-KBvgjRiYr4H+BPemZ9AbsRBTjfV8VyoJXWeIhWRpGGM=",
      "url": "_framework/System.Text.RegularExpressions.wiruy7mfvu.wasm"
    },
    {
      "hash": "sha256-ZkZ8Op2kO+/VyXA+7vydWgGn/Qyi+D14GO1sPctlAuA=",
      "url": "_framework/System.Threading.Channels.i679hva8jt.wasm"
    },
    {
      "hash": "sha256-z1iV5awhhL6RgaTPYOMwOnffXqUexwPEZRRxKb7hcHQ=",
      "url": "_framework/System.Threading.Overlapped.xgppiu9pgg.wasm"
    },
    {
      "hash": "sha256-2QNkWNgYEMgSq2eVsaqurIipive3faSFQMy3fvIg2hE=",
      "url": "_framework/System.Threading.Tasks.Dataflow.l9wmvyrnpy.wasm"
    },
    {
      "hash": "sha256-0+xvz6MW1zby2j3HxhRYOBZrRR8W+5Ye4u6WbsxmNFs=",
      "url": "_framework/System.Threading.Tasks.Extensions.plqic8lnum.wasm"
    },
    {
      "hash": "sha256-VTJigqZwPlnL2DbEO35M9qCY0rU9KWBo+8ifzfn+mrE=",
      "url": "_framework/System.Threading.Tasks.Parallel.n95077t89s.wasm"
    },
    {
      "hash": "sha256-e1DVL5/yySprqcSlcuRX2DFsrzb/58EAjHQAZsQka4Q=",
      "url": "_framework/System.Threading.Tasks.bodxp5md30.wasm"
    },
    {
      "hash": "sha256-kNNJLNli56uGVafj+IbXHyHi3kxi++SHgkgVgdrWTwk=",
      "url": "_framework/System.Threading.Thread.s9pmvp4dck.wasm"
    },
    {
      "hash": "sha256-I9CBfWllrXbj0ZRerFEOHTmQEK3dhvnDQues6CDZGnA=",
      "url": "_framework/System.Threading.ThreadPool.1r53w44obc.wasm"
    },
    {
      "hash": "sha256-RYQAjjpQoT7/+WFUEWchFaCK3uP8RSaqaIxASZelhGo=",
      "url": "_framework/System.Threading.Timer.bk6aoxcdg1.wasm"
    },
    {
      "hash": "sha256-MTgHrOERwXu3EnLv9ZLZhOqfRawRZWsEFvQZ3DJtKJc=",
      "url": "_framework/System.Threading.nirauoqlif.wasm"
    },
    {
      "hash": "sha256-khXUubdudONUrUwKqj3WK8Zyqui8hzHs1pfGky2c9zM=",
      "url": "_framework/System.Transactions.Local.iwo2vba8ej.wasm"
    },
    {
      "hash": "sha256-V6MhPoB+qdPiZxsKQt7Dw4NfddLPaGTbauNCnf3ZC/Q=",
      "url": "_framework/System.Transactions.tvf1mslhx4.wasm"
    },
    {
      "hash": "sha256-6TvPtcuIVyyn/g+l9iex+tHmkY6N9Sy/2kLKgzm7DCc=",
      "url": "_framework/System.ValueTuple.78jn7v8dlr.wasm"
    },
    {
      "hash": "sha256-6dF1b6NdsPbsShH1K1suz57JOanfT1bBwvP9brFs5DY=",
      "url": "_framework/System.Web.7g91klgltw.wasm"
    },
    {
      "hash": "sha256-ccCsMli2p6l/YuYk+eFv1BiGAH37OAQDT4lS/Q5S/ow=",
      "url": "_framework/System.Web.HttpUtility.lzjl0iada5.wasm"
    },
    {
      "hash": "sha256-a0g3LM0O0zrB9HmB3HBiynOoDBUdxoC8pFYA/dFeNEQ=",
      "url": "_framework/System.Windows.tqlan9z3e7.wasm"
    },
    {
      "hash": "sha256-WFyy6bgJg+LbCUH0jP/DHfTF9dcFypei5LPBJSRWAzE=",
      "url": "_framework/System.Xml.0mpwac2d37.wasm"
    },
    {
      "hash": "sha256-dtdsWwTAwdvu5wFFi5lux2tuM7+y/96WS9mgW2W/ENI=",
      "url": "_framework/System.Xml.Linq.unrysn9qax.wasm"
    },
    {
      "hash": "sha256-/EQs6Aas83hLTVT9Ejvg/XSeoWQtG0GRJZby0EvRMNM=",
      "url": "_framework/System.Xml.ReaderWriter.cohqtjcpf0.wasm"
    },
    {
      "hash": "sha256-7AB+it/XOtOTmwlkCbtDA61dSu5L7OfvcQ9R8H8P30w=",
      "url": "_framework/System.Xml.Serialization.o7clahiyuf.wasm"
    },
    {
      "hash": "sha256-rhB43F194QEu1gmNjELxihWdVElt9I+EwW45kqt/eNU=",
      "url": "_framework/System.Xml.XDocument.ifo87nwrrz.wasm"
    },
    {
      "hash": "sha256-aYNN4SahZdX80i+uvwbiookdXq27aHF1lyU4hq8jdL0=",
      "url": "_framework/System.Xml.XPath.31z9v5fb9t.wasm"
    },
    {
      "hash": "sha256-LXI9WMAdY7RlpFLKJN6PWAX6QVKkoS1LElF3ouAsU5s=",
      "url": "_framework/System.Xml.XPath.XDocument.l2do22ll0j.wasm"
    },
    {
      "hash": "sha256-LsZmwJld5DBRTZajpivXN9n2m7bzbwj5GtrQeIMnQqI=",
      "url": "_framework/System.Xml.XmlDocument.ynhr87n5m5.wasm"
    },
    {
      "hash": "sha256-hwWCCRlVdWr1yQPo5OQgvP9G6SuOXSgpXxZVLi5/jo4=",
      "url": "_framework/System.Xml.XmlSerializer.hmpzmynaa5.wasm"
    },
    {
      "hash": "sha256-yx4qYdR/CtnRRuvDvVqmwrSH6WEVffsgjNjfkcMSzos=",
      "url": "_framework/System.xd4kyjww0r.wasm"
    },
    {
      "hash": "sha256-Z2l1qCHQmhI+XmGzca/vmPB5owlLgebSArVh56fmlCI=",
      "url": "_framework/WindowsBase.nwppejyczt.wasm"
    },
    {
      "hash": "sha256-xDoSg0W/cSByocZNZUEXfSRFahmPM0c6SZ7nyZH/Aeo=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-C6VEWJvr8/4p8V9CoiDu1P5WjlEOa5J8TwcJ/G/8V14=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-r+0JJkNRopcjCdvu4kNlzuZR2a6pE+/WCMG/1eFdRCI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-6WQtr0F8Ko51F3GzWwMIldPl57Xrw+TkJWpe/cIKA8Y=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-CZ1sIk5M2RH428ZygXROUF+6a84HY8MGMwDrhoCUEW0=",
      "url": "_framework/dotnet.native.bzwws2hkcc.wasm"
    },
    {
      "hash": "sha256-cey0ipeo2dBuGCuBCYa94Mjci9UONuhwJhOfouxiaTU=",
      "url": "_framework/dotnet.native.x4kezr0d10.js"
    },
    {
      "hash": "sha256-1lGQC47gePi9fLGPDXRbA//I7x1RZ2FrSoAwS/Piloo=",
      "url": "_framework/dotnet.runtime.26xtx0erx2.js"
    },
    {
      "hash": "sha256-gWuhfxk/gvHZ5jozK+rQ3gQveWkBryP65IUYQfMYXbA=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vUXhuc/U6mesLSlOS2lK97qicSLfwAsbTIXEDL540dg=",
      "url": "_framework/mscorlib.v18eefjw8o.wasm"
    },
    {
      "hash": "sha256-WnnQvCWbqjV58ykaX6M1J9L00ZkzCBHT4J9PBWJqT0Q=",
      "url": "_framework/netstandard.ii0v5wot7u.wasm"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-in6edMPv4xz5o36YnNjbEyv06mdwKykQSJy22CeeWj4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-wg7Xvspfx9tgTRxBXkR83WodsQ9XvMpfa8e+smINkxA=",
      "url": "js/pyodideRunner.js"
    },
    {
      "hash": "sha256-xdQQ7FdkWQyifr1pVpsFsNOVLhIa6AFF66xYjE9N6cQ=",
      "url": "js/recording.js"
    },
    {
      "hash": "sha256-EF4lVNETar6IToEICghbByjAbtpEJlt0i088uPaGH+c=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
